# -*- coding: utf-8 -*-
from text2phonemesequence.text2phonemesequence import Text2PhonemeSequence

__version__ = "0.0.1"
__all__ = [
    "Text2PhonemeSequence"
]